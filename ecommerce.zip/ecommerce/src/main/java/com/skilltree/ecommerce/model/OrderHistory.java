package com.skilltree.ecommerce.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "order")
public class OrderHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long shippingId;
    private Long paymentId;
    private BigDecimal totalAmount;
    private LocalDateTime placedAt;

    @OneToMany(mappedBy = "order", fetch = FetchType.LAZY)
    private List<OrderItem> items;

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public Long getShippingId() { return shippingId; }
    public Long getPaymentId() { return paymentId; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public LocalDateTime getPlacedAt() { return placedAt; }
    public List<OrderItem> getItems() { return items; }

    public void setId(Long id) { this.id = id; }
    public void setUserId(Long userId) { this.userId = userId; }
    public void setShippingId(Long shippingId) { this.shippingId = shippingId; }
    public void setPaymentId(Long paymentId) { this.paymentId = paymentId; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
    public void setPlacedAt(LocalDateTime placedAt) { this.placedAt = placedAt; }
    public void setItems(List<OrderItem> items) { this.items = items; }

}