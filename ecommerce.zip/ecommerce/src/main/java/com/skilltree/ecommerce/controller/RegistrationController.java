package com.skilltree.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.skilltree.ecommerce.model.User;
import com.skilltree.ecommerce.service.UserService;
import com.skilltree.ecommerce.dto.RegistrationRequest;
import com.skilltree.ecommerce.dto.RegistrationResponse;


@RestController
@RequestMapping("/api")
public class RegistrationController {

    @Autowired
    private UserService userService;
    //@CrossOrigin(origins = {"http://localhost:8080", "http://ecommerce-skilltree:8080"})
    @PostMapping("/register")
  
    public ResponseEntity<RegistrationResponse> registerUser(@RequestBody RegistrationRequest request) {
        RegistrationResponse response = userService.registerUser(request);
        return ResponseEntity.ok(response);

    }
}