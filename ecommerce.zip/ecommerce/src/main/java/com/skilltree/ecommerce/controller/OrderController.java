package com.skilltree.ecommerce.controller;

import com.skilltree.ecommerce.dto.OrderHistoryDTO;
import com.skilltree.ecommerce.dto.PlaceOrderRequest;
import com.skilltree.ecommerce.dto.PlaceOrderResponse;
import com.skilltree.ecommerce.model.Order;
import com.skilltree.ecommerce.service.OrderPlacementService;
import com.skilltree.ecommerce.service.OrderHistoryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderPlacementService orderPlacementService;
    private final OrderHistoryService orderHistoryService;

    public OrderController(OrderPlacementService orderPlacementService,
                           OrderHistoryService orderHistoryService) {
        this.orderPlacementService = orderPlacementService;
        this.orderHistoryService = orderHistoryService;
    }

    @PostMapping("/placeorder")
    public ResponseEntity<PlaceOrderResponse> placeOrder(@RequestBody PlaceOrderRequest request) {
        return ResponseEntity.ok(orderPlacementService.placeOrder(
            request.getUserId(),
            request.getShippingId(),
            request.getPaymentId()
        ));
    }

   
    
    @GetMapping("/history/{userId}")
    public ResponseEntity<List<OrderHistoryDTO>> getOrderHistory(@PathVariable Long userId) {
        List<OrderHistoryDTO> history = orderHistoryService.getOrderHistoryByUserId(userId);
        return ResponseEntity.ok(history);

}
}