package com.skilltree.ecommerce.service;

import com.skilltree.ecommerce.dto.ProductCategoryDTO;
import com.skilltree.ecommerce.model.ProductCategory;
import com.skilltree.ecommerce.repository.ProductCategoryRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductCategoryService {

    private final ProductCategoryRepository categoryRepo;

    public ProductCategoryService(ProductCategoryRepository categoryRepo) {
        this.categoryRepo = categoryRepo;
    }

    public List<ProductCategoryDTO> getAllCategories() {
        return categoryRepo.findAll().stream().map(category -> {
            ProductCategoryDTO dto = new ProductCategoryDTO();
            dto.setId(category.getId());
            dto.setName(category.getName());
            dto.setDescription(category.getDescription());
            return dto;
        }).collect(Collectors.toList());
    }
}