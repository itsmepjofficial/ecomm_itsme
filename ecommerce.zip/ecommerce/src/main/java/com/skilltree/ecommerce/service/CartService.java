package com.skilltree.ecommerce.service;

import com.skilltree.ecommerce.dto.CartDTO;
import com.skilltree.ecommerce.dto.CartItemDTO;
import com.skilltree.ecommerce.dto.CartItemRequestDTO;
import com.skilltree.ecommerce.model.Cart;
import com.skilltree.ecommerce.model.CartItem;
import com.skilltree.ecommerce.model.Product;
import com.skilltree.ecommerce.repository.CartItemRepository;
import com.skilltree.ecommerce.repository.CartRepository;
import com.skilltree.ecommerce.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CartService {

    private final CartRepository cartRepo;
    private final CartItemRepository itemRepo;
    private final ProductRepository productRepo;

    public CartService(CartRepository cartRepo, CartItemRepository itemRepo, ProductRepository productRepo) {
        this.cartRepo = cartRepo;
        this.itemRepo = itemRepo;
        this.productRepo = productRepo;
    }

    public CartDTO getCartByUserId(Long userId) {
        Cart cart = cartRepo.findByUserId(userId);
        if (cart == null) return null;

        CartDTO dto = new CartDTO();
        dto.setCartId(cart.getId());
        dto.setUserId(cart.getUserId());

        List<CartItemDTO> itemDTOs = cart.getItems().stream().map(item -> {
            CartItemDTO itemDTO = new CartItemDTO();
            itemDTO.setProductId(item.getProduct().getId());
            itemDTO.setProductName(item.getProduct().getName());
            itemDTO.setPrice(item.getProduct().getPrice());
            itemDTO.setQuantity(item.getQuantity());
            itemDTO.setImageUrl(item.getProduct().getImageUrl());
            return itemDTO;
        }).collect(Collectors.toList());

        dto.setItems(itemDTOs);
        return dto;
    }

    public void addItemToCart(CartItemRequestDTO request) {
        Cart cart = cartRepo.findByUserId(request.getUserId());
        if (cart == null) {
            cart = new Cart();
            cart.setUserId(request.getUserId());
            cart = cartRepo.save(cart);
        }

        Product product = productRepo.findById(request.getProductId()).orElseThrow();

        // Check if item already exists in cart
        CartItem existingItem = cart.getItems().stream()
            .filter(item -> item.getProduct().getId().equals(request.getProductId()))
            .findFirst()
            .orElse(null);

        if (existingItem != null) {
            // Update quantity
            existingItem.setQuantity(request.getQuantity());
            itemRepo.save(existingItem);
        } else {
            // Add new item
            CartItem newItem = new CartItem();
            newItem.setCart(cart);
            newItem.setProduct(product);
            newItem.setQuantity(request.getQuantity());
            itemRepo.save(newItem);
        }
    }

    public void removeItemFromCart(CartItemRequestDTO request) {
        Cart cart = cartRepo.findByUserId(request.getUserId());
        if (cart != null) {
            itemRepo.deleteByCartIdAndProduct_Id(cart.getId(), request.getProductId());
        }
    }
}