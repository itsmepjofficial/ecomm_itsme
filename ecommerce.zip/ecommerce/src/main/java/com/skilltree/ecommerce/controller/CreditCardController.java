package com.skilltree.ecommerce.controller;

import com.skilltree.ecommerce.dto.CreditCardDTO;
import com.skilltree.ecommerce.model.CreditCard;
import com.skilltree.ecommerce.service.CreditCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cards")
public class CreditCardController {

    @Autowired
    private CreditCardService service;

    @GetMapping("/{userId}")
    public List<CreditCard> getCards(@PathVariable Long userId) {
        return service.getByUserId(userId);
    }

    @PostMapping("/{userId}")
    public CreditCard addCard(@PathVariable Long userId, @RequestBody CreditCardDTO dto) {
        return service.create(userId, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCard(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok().build();
    }
}