package com.skilltree.ecommerce.dto;

import java.sql.Timestamp;
import java.util.List;

public class OrderHistoryDTO {

    private Long orderId;
    private Timestamp placedAt;
    private Double totalAmount;
    private List<OrderItemDTO> items;

    // Getters and Setters
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public Timestamp getPlacedAt() { return placedAt; }
    public void setPlacedAt(Timestamp placedAt) { this.placedAt = placedAt; }

    public Double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(Double totalAmount) { this.totalAmount = totalAmount; }

    public List<OrderItemDTO> getItems() { return items; }
    public void setItems(List<OrderItemDTO> items) { this.items = items; }
}