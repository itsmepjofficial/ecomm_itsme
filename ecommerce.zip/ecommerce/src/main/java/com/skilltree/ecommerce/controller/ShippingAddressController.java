package com.skilltree.ecommerce.controller;

import com.skilltree.ecommerce.dto.ShippingAddressDTO;
import com.skilltree.ecommerce.model.ShippingAddress;
import com.skilltree.ecommerce.service.ShippingAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shipping")
public class ShippingAddressController {

    @Autowired
    private ShippingAddressService service;

    @GetMapping("/{userId}")
    public List<ShippingAddress> getAddresses(@PathVariable Long userId) {
        return service.getByUserId(userId);
    }

    @PostMapping("/{userId}")
    public ShippingAddress addAddress(@PathVariable Long userId, @RequestBody ShippingAddressDTO dto) {
        return service.create(userId, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAddress(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok().build();
    }
}