package com.skilltree.ecommerce.service;

import com.skilltree.ecommerce.dto.RegistrationRequest;
import com.skilltree.ecommerce.dto.RegistrationResponse;

//import com.skilltree.ecommerce.model.User;
import com.skilltree.ecommerce.model.User;
import com.skilltree.ecommerce.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

   // @Autowired
    //private PasswordEncoder passwordEncoder; // Optional: remove if not using Spring Security

    public RegistrationResponse registerUser(RegistrationRequest request) {
        // Check for duplicate username
        if (userRepository.existsByUsername(request.getUsername())) {
            return new RegistrationResponse(false, "Username already exists. Please choose a different one.", null);
        }

        // Create and populate user
        User user = new User();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setUsername(request.getUsername());

       // user.setPassword(passwordEncoder.encode(request.getPassword())); // Or just setPassword(request.getPassword()) if not encoding
        user.setPassword(request.getPassword());
        // Save user and return response
        User savedUser = userRepository.save(user);
        return new RegistrationResponse(true, "User registered successfully", savedUser.getRegistrationId());
    }
}