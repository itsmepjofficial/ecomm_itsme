package com.skilltree.ecommerce.service;

import com.skilltree.ecommerce.dto.CartItemDTO;
import com.skilltree.ecommerce.dto.PlaceOrderResponse;
import com.skilltree.ecommerce.model.Order;
import com.skilltree.ecommerce.model.OrderItem;
import com.skilltree.ecommerce.model.CartItem;
import com.skilltree.ecommerce.repository.CartItemRepository;
import com.skilltree.ecommerce.repository.OrderItemRepository;
import com.skilltree.ecommerce.repository.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderPlacementService {

    private final CartItemRepository cartItemRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;

    public OrderPlacementService(CartItemRepository cartItemRepository,
                                 OrderRepository orderRepository,
                                 OrderItemRepository orderItemRepository) {
        this.cartItemRepository = cartItemRepository;
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
    }

    @Transactional
    public PlaceOrderResponse placeOrder(Long userId, Long shippingId, Long paymentId) {
    	
    	System.out.println("DEBUG: userId=" + userId + ", shippingId=" + shippingId + ", paymentId=" + paymentId);


    	
    	if (shippingId == null || shippingId <= 0) {
    	        throw new IllegalArgumentException("Shipping address is required to place an order.");
    	    }

    	    if (paymentId == null || paymentId <= 0) {
    	        throw new IllegalArgumentException("Payment method is required to place an order.");
    	    }

    	    List<CartItem> cartItems = cartItemRepository.findByUserId(userId);

        if (cartItems == null || cartItems.isEmpty()) {
            throw new IllegalArgumentException("Cart is empty. Cannot place order.");
        }

        double totalAmount = 0.0;
        List<OrderItem> orderItems = new ArrayList<>();

        for (CartItem cartItem : cartItems) {
            if (cartItem.getProduct() == null) {
                throw new IllegalStateException("Product reference missing for cart item ID: " + cartItem.getId());
            }

            double price = cartItem.getProduct().getPrice();
            totalAmount += price * cartItem.getQuantity();

            OrderItem orderItem = new OrderItem();
           // orderItem.setProductId(cartItem.getProductId());
            orderItem.setProduct(cartItem.getProduct());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPriceAtOrder(price);
            orderItems.add(orderItem);
        }

        Order order = new Order();
        order.setUserId(userId);
        order.setShippingId(shippingId);
        order.setPaymentId(paymentId);
        order.setTotalAmount(totalAmount);
        order.setPlacedAt(Timestamp.from(Instant.now()));

        orderRepository.save(order);

        for (OrderItem item : orderItems) {
            item.setOrder(order);
        }

        orderItemRepository.saveAll(orderItems);

        // Optional: Clear cart after order
        Long cartId = cartItems.get(0).getCart().getId();
        cartItemRepository.deleteByCartId(cartId);

        PlaceOrderResponse response = new PlaceOrderResponse();
        response.setOrderId(order.getId());
        response.setTotalAmount(order.getTotalAmount());
        response.setPlacedAt(order.getPlacedAt());

        return response;
    }
}