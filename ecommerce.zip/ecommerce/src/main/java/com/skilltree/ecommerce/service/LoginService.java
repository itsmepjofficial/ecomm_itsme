package com.skilltree.ecommerce.service;

import com.skilltree.ecommerce.dto.LoginRequest;
import com.skilltree.ecommerce.dto.LoginResponse;
import com.skilltree.ecommerce.model.User;
import com.skilltree.ecommerce.repository.UserRepository;
import com.skilltree.ecommerce.security.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;

@Service
public class LoginService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    public LoginResponse authenticate(LoginRequest request) {
        Optional<User> userOpt = userRepository.findByUsername(request.getUsername());

        if (userOpt.isEmpty()) {
            return new LoginResponse(false, "User not found", null);
        }

        User user = userOpt.get();
        if (!user.getPassword().equals(request.getPassword())) {
            return new LoginResponse(false, "Invalid password", null);
        }

        return new LoginResponse(true, "Login successful", user.getId());
    }

    public String generateToken(String username) {
        return jwtUtil.generateToken(username, Map.of());
    }

}