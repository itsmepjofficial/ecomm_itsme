package com.skilltree.ecommerce.service;

import com.skilltree.ecommerce.dto.OrderHistoryDTO;
import com.skilltree.ecommerce.dto.OrderItemDTO;
import com.skilltree.ecommerce.model.Order;
import com.skilltree.ecommerce.model.OrderItem;
import com.skilltree.ecommerce.model.Product;
import com.skilltree.ecommerce.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderHistoryService {

    private final OrderRepository orderRepository;

    public OrderHistoryService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public List<OrderHistoryDTO> getOrderHistoryByUserId(Long userId) {
        List<Order> orders = orderRepository.findByUserId(userId);

        return orders.stream().map(order -> {
            OrderHistoryDTO dto = new OrderHistoryDTO();
            dto.setOrderId(order.getId());
            dto.setPlacedAt(order.getPlacedAt());
            dto.setTotalAmount(order.getTotalAmount());

            List<OrderItemDTO> itemDTOs = order.getItems().stream().map(item -> {
                OrderItemDTO itemDTO = new OrderItemDTO();
                itemDTO.setProductId(item.getProduct() != null ? item.getProduct().getId() : null);
                itemDTO.setQuantity(item.getQuantity());
                itemDTO.setPriceAtOrder(item.getPriceAtOrder());

                Product product = item.getProduct();
                if (product != null) {
                    itemDTO.setProductName(product.getName());
                    itemDTO.setImageUrl(product.getImageUrl());
                }

                return itemDTO;
            }).collect(Collectors.toList());

            dto.setItems(itemDTOs);
            return dto;
        }).collect(Collectors.toList());
    }
}