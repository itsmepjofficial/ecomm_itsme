package com.skilltree.ecommerce.controller;

import com.skilltree.ecommerce.dto.CartDTO;
import com.skilltree.ecommerce.dto.CartItemRequestDTO;
import com.skilltree.ecommerce.service.CartService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping
    public CartDTO getCart(@RequestParam Long userId) {
        return cartService.getCartByUserId(userId);
    }

    @PostMapping("/items")
    public void addItem(@RequestBody CartItemRequestDTO request) {
        cartService.addItemToCart(request);
    }

    @DeleteMapping("/items")
    public void removeItem(@RequestBody CartItemRequestDTO request) {
        cartService.removeItemFromCart(request);
    }
}