package com.skilltree.ecommerce.controller;

import com.skilltree.ecommerce.dto.LoginRequest;
import com.skilltree.ecommerce.dto.LoginResponse;
import com.skilltree.ecommerce.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        LoginResponse response = loginService.authenticate(request);

        if (!response.isSuccess()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }

        String token = loginService.generateToken(request.getUsername());

        return ResponseEntity.ok()
                .header("Authorization", "Bearer " + token)
                .body(response);
    }
}