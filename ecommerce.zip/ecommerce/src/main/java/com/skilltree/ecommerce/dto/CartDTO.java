package com.skilltree.ecommerce.dto;

import java.util.List;

public class CartDTO {
    private Long cartId;
    private Long userId;
    private List<CartItemDTO> items;

    // Getters and Setters
    public Long getCartId() { return cartId; }
    public void setCartId(Long cartId) { this.cartId = cartId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public List<CartItemDTO> getItems() { return items; }
    public void setItems(List<CartItemDTO> items) { this.items = items; }
}