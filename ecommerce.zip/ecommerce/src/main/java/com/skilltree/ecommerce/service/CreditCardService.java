package com.skilltree.ecommerce.service;

import com.skilltree.ecommerce.dto.CreditCardDTO;
import com.skilltree.ecommerce.model.CreditCard;
import com.skilltree.ecommerce.repository.CreditCardRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CreditCardService {

    @Autowired
    private CreditCardRepository repository;

    public List<CreditCard> getByUserId(Long userId) {
        return repository.findByUserId(userId);
    }

    public CreditCard create(Long userId, CreditCardDTO dto) {
        CreditCard card = new CreditCard();
        BeanUtils.copyProperties(dto, card);
        card.setUserId(userId);
        return repository.save(card);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}