package com.skilltree.ecommerce.service;

import com.skilltree.ecommerce.dto.ProductDTO;
import com.skilltree.ecommerce.model.Product;
import com.skilltree.ecommerce.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    private final ProductRepository productRepo;

    public ProductService(ProductRepository productRepo) {
        this.productRepo = productRepo;
    }

    public List<ProductDTO> getProductsByCategory(Long categoryId) {
        return productRepo.findByCategoryId(categoryId).stream().map(product -> {
            ProductDTO dto = new ProductDTO();
            dto.setId(product.getId());
            dto.setName(product.getName());
            dto.setPrice(product.getPrice());
            dto.setDiscountPercent(product.getDiscountPercent());
            dto.setRating(product.getRating());
            dto.setImageUrl(product.getImageUrl());
            dto.setDeliveryInfo(product.getDeliveryInfo());
            dto.setCategoryId(product.getCategory().getId());
            dto.setCategoryName(product.getCategory().getName());
            return dto;
        }).collect(Collectors.toList());
    }
}