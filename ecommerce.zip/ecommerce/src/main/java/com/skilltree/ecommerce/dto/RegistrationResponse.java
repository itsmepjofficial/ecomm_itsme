package com.skilltree.ecommerce.dto;

public class RegistrationResponse {
    private boolean success;
    private String message;
    private String registrationId;

    public RegistrationResponse(boolean success, String message, String registrationId) {
        this.success = success;
        this.message = message;
        this.registrationId = registrationId;
    }

    // Getters and setters
    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getRegistrationId() { return registrationId; }
    public void setRegistrationId(String registrationId) { this.registrationId = registrationId; }
}