package com.skilltree.ecommerce.repository;

import com.skilltree.ecommerce.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderHistoryRepository extends JpaRepository<Order, Long> {
    List<Order> findByUserId(Long userId);
}