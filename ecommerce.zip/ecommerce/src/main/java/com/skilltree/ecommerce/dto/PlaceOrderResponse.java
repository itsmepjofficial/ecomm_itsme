package com.skilltree.ecommerce.dto;

import java.sql.Timestamp;

public class PlaceOrderResponse {
    private Long orderId;
    private String message;

    public PlaceOrderResponse() {}

    public PlaceOrderResponse(Long orderId, String message) {
        this.orderId = orderId;
        this.message = message;
    }
    
    private Double totalAmount;
    private Timestamp placedAt;

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Timestamp getPlacedAt() {
        return placedAt;
    }

    public void setPlacedAt(Timestamp placedAt) {
        this.placedAt = placedAt;
    }


    // Getters and Setters
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}