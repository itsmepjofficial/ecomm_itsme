package com.skilltree.ecommerce.service;

import com.skilltree.ecommerce.dto.ShippingAddressDTO;
import com.skilltree.ecommerce.model.ShippingAddress;
import com.skilltree.ecommerce.repository.ShippingAddressRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShippingAddressService {

    @Autowired
    private ShippingAddressRepository repository;

    public List<ShippingAddress> getByUserId(Long userId) {
        return repository.findByUserId(userId);
    }

    public ShippingAddress create(Long userId, ShippingAddressDTO dto) {
        ShippingAddress address = new ShippingAddress();
        BeanUtils.copyProperties(dto, address);
        address.setUserId(userId);
        return repository.save(address);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}