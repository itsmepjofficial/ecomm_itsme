package com.skilltree.ecommerce.controller;

import com.skilltree.ecommerce.dto.ProductDTO;
import com.skilltree.ecommerce.service.ProductService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public List<ProductDTO> getProducts(@RequestParam Long categoryId) {
        return productService.getProductsByCategory(categoryId);
    }
}