package com.skilltree.ecommerce.controller;

import com.skilltree.ecommerce.dto.ProductCategoryDTO;
import com.skilltree.ecommerce.service.ProductCategoryService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
public class ProductCategoryController {

    private final ProductCategoryService categoryService;

    public ProductCategoryController(ProductCategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping
    public List<ProductCategoryDTO> getCategories() {
        return categoryService.getAllCategories();
    }
}